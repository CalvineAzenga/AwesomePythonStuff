  $('.dropdown-trigger').dropdown();



  $(document).ready(function(){
    $('select').formSelect();
  });
        